#!/usr/bin/env bash
# source : https://github.com/envygeeks/jekyll-docker/blob/master/README.md

${PWD}/docker-nodejs-cmd.sh npm run build