#!/usr/bin/env bash

${PWD}/docker-nodejs-cmd.sh npm run build