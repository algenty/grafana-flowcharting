#!/usr/bin/env bash
# source : https://github.com/envygeeks/jekyll-docker/blob/master/README.md

${PWD}/nodejs-cmd.sh npm run sign
