#!/usr/bin/env bash

${PWD}/nodejs-cmd.sh npx npm-check-updates
