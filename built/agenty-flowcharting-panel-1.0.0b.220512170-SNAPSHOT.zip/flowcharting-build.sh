#!/usr/bin/env bash

${PWD}/nodejs-cmd.sh npm run build
